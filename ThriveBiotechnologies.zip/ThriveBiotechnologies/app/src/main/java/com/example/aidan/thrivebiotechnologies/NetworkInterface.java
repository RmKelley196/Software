package com.example.aidan.thrivebiotechnologies;

import android.os.AsyncTask;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import com.example.aidan.thrivebiotechnologies.MainActivity;

/**
 * Created by Aidan on 2/18/2018.
 */

public class NetworkInterface implements Runnable
{

    // Declaration of socket object variables.
    public Socket s = null;
    public DataOutputStream dos;
    public DataInputStream dis;

    // Communication standard constants, ideally these will not be needed eventually.
    char indichar = '^';
    int code = 1997;

    public void initConnection (String address)
    {
        int port = 4444;

        // Initializes socket connection.
        try
        {
            MainActivity.recievedField.append("Trying to connect to " + address + ".\n");
            s = new Socket(address, port);
            MainActivity.recievedField.append("Connected to the socket.\n");
        }
        catch (Exception e)
        {
            MainActivity.recievedField.append("Could not connect to the socket.\n");
            MainActivity.recievedField.append(e.toString() + "\n");
            //e.printStackTrace();
            return;
        }

        // After successful connection established, sets up I/O objects.
        try
        {
            dos = new DataOutputStream(s.getOutputStream());
            dis = new DataInputStream(s.getInputStream());
        }
        catch (IOException e)
        {

            MainActivity.recievedField.append("Connection Issue\n");
            //e.printStackTrace();
            return;
        }

        // Initializes receive thread.
        Thread t = new Thread(this);
        t.start();

        return;
    }

    public void sendMessage (String message)
    {
        try
        {
            // Needs to be modified for use with GUI.
            MainActivity.recievedField.append("Sending message: " + message + "\n");

            message = Character.toString(indichar) + Integer.toString(code) + message + "\r\n";
            dos.writeUTF(message);
        }
        catch (IOException e)
        {
            MainActivity.recievedField.append("Host Disconnected\n");
            return;
            //e.printStackTrace();
        }
    }

    @Override
    public void run()
    {
        String received = "";

        // Receive thread.
        while (true)
        {
            try
            {
                received = (String)dis.readUTF();

                if (!received.equals(""))
                {
                    // This is where GUI interaction and math should occur.
                    MainActivity.recievedField.append("Received Message: " + received + "\n");

                    received = "";
                }
            }
            catch (IOException e)
            {
                MainActivity.recievedField.append("Host Disconnected\n");
                break;
                //e.printStackTrace();
            }
        }

        // Closes object connections on host disconnection.
        try {
            dos.close();
            dis.close();
            s.close();
        } catch (IOException e) {
            // Either the program should break before getting here, or something went absurdly wrong.
            MainActivity.recievedField.append("Everything is Broken");
            MainActivity.recievedField.append(e.toString());
        }

        return;
    }
}
