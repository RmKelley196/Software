package com.example.aidan.thrivebiotechnologies;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.aidan.thrivebiotechnologies.NetworkInterface;

public class MainActivity extends AppCompatActivity
{

    public Button connectButton;
    public Button sendButton;
    public EditText addressField;
    public EditText messageField;
    public static TextView recievedField;
    final NetworkInterface net = new NetworkInterface();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        // setContentView(R.layout.content_layout_id);

        addressField = findViewById(R.id.addressField);
        messageField = findViewById(R.id.messageField);

        recievedField = findViewById(R.id.recievedField);
        recievedField.setText("");

        connectButton = findViewById(R.id.connectButton);
        connectButton.setOnClickListener(new View.OnClickListener()
        {
          public void onClick(View v) {
              net.initConnection(addressField.getText().toString());
          }
        });

        sendButton = findViewById(R.id.sendButton);
        sendButton.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v) {
                net.sendMessage(messageField.getText().toString());
                messageField.getText().clear();
            }
        });
    }
}
